##############################################
setwd("C:/JoseeR/A_Spatial_stats")
##############################################
#Read data cod data

cod=read.table("cod.txt")
str(cod)
head(cod)

hist(cod$V3)
cod$cod.log=log(cod$V3)
hist(cod$cod.log)
codxy=cbind(cod$V1,cod$V2)
str(codxy)
xyeucli=dist(codxy)
hist(xyeucli)
str(xyeucli)
xyeucli=as.matrix(xyeucli)
str(xyeucli)
maxdist=2/3*(max(xyeucli))
maxdist
###############################################
library(spdep)
#make a neighborhood list:
distmat <- dist(codxy)
str(distmat)
coords=coordinates(codxy)
neigh <- dnearneigh(x = codxy, d1 = 0, d2 = maxdist, longlat = F)
#plot the neighborhood; 
plot(coords)
#plot(neigh, coordinates(coords))
wts <- nb2listw(neighbours = neigh, style = 'W', zero.policy =  T)

mor.mc <- moran.mc(x = cod$cod.log, listw = wts, 
                   nsim = 99, zero.policy = T)
mor.mc
mor.norm <- moran.test(x = cod$cod.log, listw = wts, 
                       randomisation = F, zero.policy = T)
mor.norm
#################################################
library(pgirmess)
#correlog from pgirmess 10 classes
cod.pgirmess.10 <- correlog(coords, cod$cod.log, method = "Moran", nbclass = 10, alternative = "two.sided") 
#summary of 10 classes
head(round(cod.pgirmess.10, 2))
cod.pgirmess.10=round(cod.pgirmess.10, 2)
cod.pgirmess.10
plot(cod.pgirmess.10)
abline(h = 0)

#correlog from pgirmess 20 classes
cod.pgirmess.20 <- correlog(coords, cod$cod.log, method = "Moran", nbclass = 20, alternative = "two.sided") 
#summary of 20 classes
head(round(cod.pgirmess.20, 2))
cod.pgirmess.20=round(cod.pgirmess.20, 2)
cod.pgirmess.20

plot(cod.pgirmess.20)
abline(h = 0)
#################################################
############################################################## 
#Variogram
#load packages
library(geoR)
codxyz=cbind(cod$V1,cod$V2,cod$cod.log)
#create a geoR object
geo.cod <- as.geodata(codxyz)

#Empirical semivariogram 
emp.geoR <- variog(geo.cod, max.dist = maxdist)
plot(emp.geoR)

#standardize break points to a minimum 1000-m lag distance 
emp.geoR <- variog(geo.cod, max.dist = maxdist, 
                   breaks = c(seq(0, maxdist, by = 1000)))
plot(emp.geoR)

#in geoR, variogram in each direction
emp4.geoR <- variog4(geo.cod, max.dist = maxdist)
plot(emp4.geoR)
plot(emp4.geoR,legend=F)

#exponential variogram
mlexp <- likfit(geo.cod, cov.model = "exp", ini = c(2, 1000))
summary(mlexp)

#spherical variogram
mlsph <- likfit(geo.cod, cov.model = "sph", ini = c(2, 1000))
summary(mlsph)

AIC(mlexp, mlsph)

plot(emp.geoR,legend=F)
lines(mlexp, col = "blue")
lines(mlsph, col = "red")

emp.env <- variog.mc.env(geo.cod, obj.var = emp.geoR)
plot(emp.geoR, envelope = emp.env)
lines(mlexp, col = "blue")
############################################################
#Kriging
#grid to interpolate
head(codxyz)
min(codxyz[,1])
max(codxyz[,1])
min(codxyz[,2])
max(codxyz[,2])

x <- seq(600000, 750000, by=5000)
y <- seq(5400000, 5570000, by=5000)
cod.grid <- expand.grid(x = x, y = y)
str(cod.grid)

#kriging: krige.control, cov.pars: partial sill, range
krig.geoR.exp <- krige.conv(geo.cod, 
    locations = cod.grid,
    krige = krige.control(cov.pars = c(mlexp$cov.pars[1], mlexp$cov.pars[2]),
    nugget =  mlexp$nugget, cov.model = "exp", type.krige = "OK")) 
                                                                                
#get the prediction values for the kriged surface 
image(krig.geoR.exp, val = krig.geoR.exp$predict, main = "kriging estimates")
image(krig.geoR.exp, val = sqrt(krig.geoR.exp$krige.var), main = "kriging SE")
##########################################################
#################################################
#Spatial Correlation: Dutilleul's Correction
#install.packages("SpatialPack")
library(SpatialPack)
xyenvsp=read.table("Coord_Env_Species.txt")
str(xyenvsp)
xy=cbind(xyenvsp$V1,xyenvsp$V2)
env=cbind(xyenvsp$V3,xyenvsp$V4,xyenvsp$V5,xyenvsp$V6)
spp=cbind(xyenvsp$V7,xyenvsp$V8,xyenvsp$V9,xyenvsp$V10,
          xyenvsp$V11,xyenvsp$V12,xyenvsp$V13,xyenvsp$V14,
          xyenvsp$V15,xyenvsp$V16)

modified.ttest(xyenvsp[,3],xyenvsp[,5],xy,nclass = 5)
modified.ttest(xyenvsp[,3],xyenvsp[,5],xy,nclass = 10)
modified.ttest(xyenvsp[,3],xyenvsp[,5],xy,nclass = 20)
##################################################
#Partial Mantel test
library(vegan)
dxy=dist(xy)
denv=dist(env)
dspp=dist(spp)

mantel(d01spp, d01env, method="pearson", permutations=999)
mantel.partial(d01spp, d01env,d01xy, method = "pearson", permutations = 999)
##############################################################
#Spatial Regression
#############################################################
library(ade4)
library(vegan)
library(spdep)

gen <- dist(denv)
geo <- dist(dxy)
sp <- dist(dspp)

###########
#Mantel and partial Mantel tests
plot(r_e_xy <- mantel.rtest(geo,gen), main = "Mantel env_xy")
r_e_xy

plot(r_sp_e <- mantel.rtest(gen, sp), main = "Mantel sp_env" )
r_sp_e

plot(r_sp_xy <- mantel.rtest(geo, sp), main = "Mantel sp_xy" )
r_sp_xy

mantel(geo, gen, method="pearson", permutations=999)
mantel(geo, sp, method="pearson", permutations=999)
mantel(sp, gen, method="pearson", permutations=999)

r_sp_en_xy <- mantel.partial(geo, gen, sp, method = "pearson", permutations = 999)
r_sp_en_xy
##################################################
# Redundancy analysis(RDA, function 'rda')
##################################################
library(vegan)
sp.rda <- rda(spp ~ env)
summary(sp.rda)
################################################
# Unadjusted R^2 retrieved from the rda result
R2 <- RsquareAdj(sp.rda)$r.squared
R2
# Adjusted R^2 retrieved from the rda object
R2adj <- RsquareAdj(sp.rda)$adj.r.squared
R2adj
# Significance testing
anova(sp.rda, step=1000) 
#Variance inflation factors (VIF) in RDAs
vif.cca(sp.rda)
##########################################
# Retrieve RDA site scores  (choice: axis)
siteRDA.sc <- scores(sp.rda, choices=1:2, scaling=2, display="sites")
write.csv(siteRDA.sc, "siteRDAscores.csv")
##################################################
# Create plot for RDA
plot(sp.rda)
dev.off()
###################################################
# Create correlation triplot for RDA
# Scaling 1
plot(sp.rda, scaling=1, type="none", main="Triplot RDA spe ~ env - scaling 1")
spe.sc <- scores(sp.rda, choices=1:2, scaling=1, display="spe")
env.sc <- scores(sp.rda, choices=1:2, scaling=1, display="bp")
arrows(0, 0, spe.sc[,1], spe.sc[,2], length=0, lty=1, col="red")
arrows(0, 0, env.sc[,1], env.sc[,2], length=0, lty=1, col="blue")
text(sp.rda, display="spe", scaling=1, cex=0.5, col="red")
text(sp.rda, display="bp", scaling=1, cex=0.5, col="blue")
text(sp.rda, display="sites", scaling=1, cex=0.5)

dev.off()

#############################################################