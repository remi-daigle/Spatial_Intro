#############################################################
#Read data (stems of trees in a 50x50m plot)

setwd("C:/JoseeR/A_Spatial_stats")

aspen=read.table("aspen_xy.txt")
pine=read.table("pine_xy.txt")

xyz=read.table("aspen_pine_xyz.txt")
str(xyz)

#####################################################################
#Plot_aspen
plot(aspen$V1,aspen$V2,pch=20, ann=FALSE)
grid(NULL, NULL, col = "black", lty = 1, lwd = par("lwd"), equilogs = TRUE)
#Plot_pine
plot(pine$V1,pine$V2,pch=20, ann=FALSE)
grid(NULL, NULL, col = "black", lty = "dotted", lwd = par("lwd"), equilogs = TRUE)
#Plot_aspen+pine
plot(xyz$V2,xyz$V3,pch=20, ann=FALSE)
grid(NULL, NULL, col = "black", lty = 1,lwd = par("lwd"), equilogs = TRUE)
################################################################
#Count aspen trees
install.packages("spatstat")
library(spatstat)

Xa <- ppp(aspen$V1,aspen$V2,c(0,50), c(0,50))

quadrat.test(Xa, nx = 5, ny = 5,method="Chisq")
####################################################
# Point Pattern Analysis
################################################################
#Tesselation
#library(spatstat)
plot(Xa,main="Aspen")
plot(convexhull(Xa))
plot(delaunay(Xa))
plot(dirichlet(Xa))
#Delaunay
delaunay(Xa)
plot(delaunay(Xa),main="")
plot(Xa, pch=20, add=TRUE)
################################################################
library(spdep)
xy.delo = tri2nb(aspen)
xy.delo
#summary(xy.delo)
#####################################################
#Kernel density function
plot(density(Xa, 10))
#plot(X, add = TRUE)
plot(density(Xa, sigma = 70))
###################################################################
#Delaunay: Create links based of Delaunay algorithm
library(tripack)
tritest.tr<-tri.mesh(aspen$V1,aspen$V2)
plot(tritest.tr)
#Degree of the nodes (list of neighbors) based on Delaunay links
tritest.tr
#Voronoi
tritest.vm <- voronoi.mosaic(aspen$V1,aspen$V2)
plot(tritest.vm)
################################################################
#Ripley K
#library(spatstat)
#Xa <- ppp(aspen$V1,aspen$V2,c(0,50), c(0,50))
#Ripley's K 
plot(envelope(Xa, Kest, transform=expression(sqrt(./pi)), global=TRUE))
#plot(envelope(Xa, Kest, transform=expression(sqrt(./pi)), global=TRUE),legend=F)
#dev.off()
##########################################################
K_aspen_none=Kest(Xa,correction = "none")
plot(K_aspen_none)
##########################################################
L_aspen_none <- Lest(Xa, correction="none") 
plot(L_aspen_none) #standardized to a 1:1 expectation
plot(L_aspen_none, . - r~r) #standardized to a zero expectation
################################################################
#isotropic correction uses a simple weighting of area sampled near edge 
L_aspen_iso <- Lest(Xa, correction="isotropic")
plot(L_aspen_iso, . - r~r)
###############################################################
#translate correction uses a toroidal shift
L_aspen_trans <- Lest(Xa, correction="translate")
plot(L_aspen_trans, . - r~r)
################################################################
L_aspen_csr <- envelope(Xa, Lest, nsim=99, rank=1, correction="translate", global=FALSE)
plot(L_aspen_csr, . - r~r, shade=c("hi", "lo"), legend=F) 
################################################################
#rank=1, max/min used for envelopes
#99 simulations alpha=0.01
#19 simulations alpha=0.05
################################################################
# Pair Correlation Function
#translate correction uses a toroidal shift
P_aspen_trans <- pcf(Xa, correction="translate")
plot(P_aspen_trans)

P_aspen_env <- envelope(Xa, pcf, nsim=99, rank=1, correction="translate", global=FALSE)
plot(P_aspen_env, shade=c("hi", "lo"), legend=FALSE)
###########################
#G-function
G_aspen_trans <- Gest(Xa, correction="rs")
plot(G_aspen_trans)
plot(G_aspen_trans, legend=F)

G_aspen_env <- envelope(Xa, Gest, nsim=99, rank=1, correction="rs", global=FALSE)
plot(G_aspen_env)
plot(G_aspen_env, shade=c("hi", "lo"), legend=FALSE)
#############################
#Ripley's L 
plot(envelope(Xa, Lest, nsim = 99, global = FALSE), . - r ~ r,main="",legend=F)
#Ripley's L for inhomogeneous data 
plot(envelope(Xa, Linhom, nsim = 99, global = FALSE), . - r ~ r,main="",legend=F)
#################################################################
#Ripley's K 
Xp <- ppp(pine$V1,pine$V2,c(0,50), c(0,50))
plot(envelope(Xp, Kest, transform=expression(sqrt(./pi)), global=TRUE))
#Ripley's L 
plot(envelope(Xp, Lest, nsim = 99, global = FALSE), . - r ~ r,main="",legend=F)
#Ripley's L for inhomogeneous data 
plot(envelope(Xp, Linhom, nsim = 99, global = FALSE), . - r ~ r,main="",legend=F)
################################################################
#Bivariate Riple's K
xyz$V1 = as.factor(xyz$V1)   
str(xyz)
dev.off()

kap=ppp(xyz$V2,xyz$V3,c(0,50),c(0,50),marks=xyz$V1) 

kap<-alltypes(kap, Kcross, nsim = 39, envelope = TRUE)

dev.off()
plot(kap, . - r~r)
################################################################
################################################################
#nearest neighbor distance for each point
nn.dist <- nndist(Xa)

dev.off()
hist(nn.dist)
################################################################